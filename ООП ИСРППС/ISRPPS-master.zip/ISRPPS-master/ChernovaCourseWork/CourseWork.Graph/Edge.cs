﻿namespace CourseWork.Graph
{
    class Edge
    {
        public int FirstVertexIndex { get; set; }
        public int SecondVertexIndex { get; set; }
    }
}
