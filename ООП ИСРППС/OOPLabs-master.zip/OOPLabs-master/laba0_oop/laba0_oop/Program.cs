﻿using System;

namespace laba0_oop
{
    class Program
    {
        static void Main(string[] args)
        {
            Matrix m = new Matrix();
            m.PrintSize();
            m.PrintMatrix();
        }
    }
}
